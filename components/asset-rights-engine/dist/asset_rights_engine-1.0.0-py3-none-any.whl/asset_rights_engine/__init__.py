"""Asset & Rights Engine ARE-A1 1.0.0."""
from .contracts import (AssetDescriptor, AssignmentDescriptor, RightsRecord, RightsState, AssignmentState, UseContext, SceneBinding, ReviewRequest, RevisionView, Evaluation, ReviewEvent, DomainError, digest)
from .engine import Engine
from .evaluator import evaluate_effective_rights
__version__="1.0.0"
